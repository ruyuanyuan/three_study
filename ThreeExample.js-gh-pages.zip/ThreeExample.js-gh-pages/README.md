ThreeExamples.js
================

本项目是《Three.js 入门指南》的书例代码。

<a href="http://zhangwenli.com/ThreeExample.js/" target="_blank">查看代码目录</a>

《Three.js 入门指南》是一本帮助初学者更快入门 Three.js 的电子书，可在<a href="http://read.douban.com/ebook/7412854/" target="_blank">豆瓣阅读</a>和<a href="http://www.ituring.com.cn/book/1272" target="_blank">图灵社区</a>（提供推送到 Kindle 服务）免费阅读。
